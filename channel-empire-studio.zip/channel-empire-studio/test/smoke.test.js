import test from 'node:test';
import assert from 'node:assert/strict';
test('runtime supports required crypto and fetch primitives',()=>{assert.equal(typeof globalThis.fetch,'function');assert.equal(typeof globalThis.crypto.randomUUID,'function');});
