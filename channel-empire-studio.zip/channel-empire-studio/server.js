import 'dotenv/config';
import express from 'express';
import session from 'express-session';
import { google } from 'googleapis';
import OpenAI from 'openai';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve('data');
const STORE = path.join(DATA_DIR, 'store.json');
const SCOPES = ['openid','email','profile','https://www.googleapis.com/auth/youtube.readonly'];
const oauthConfigured = Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
const oauth = oauthConfigured ? new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI || `${process.env.APP_URL || `http://localhost:${PORT}`}/auth/google/callback`
) : null;

async function readStore() {
  await fs.mkdir(DATA_DIR, {recursive:true});
  try { return JSON.parse(await fs.readFile(STORE,'utf8')); }
  catch { return {channels:[], drafts:[], jobs:[]}; }
}
async function writeStore(data) {
  await fs.mkdir(DATA_DIR,{recursive:true});
  const temp = `${STORE}.${crypto.randomUUID()}.tmp`;
  await fs.writeFile(temp, JSON.stringify(data,null,2), {mode:0o600});
  await fs.rename(temp,STORE);
}
app.use(express.json({limit:'1mb'}));
app.use(session({
  name:'channel-empire.sid',
  secret:process.env.SESSION_SECRET || 'development-only-change-this-secret',
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:8*60*60*1000}
}));
app.use(express.static('public'));

function requireConfigured(req,res,next) {
  if (!oauth) return res.status(503).json({error:'Google OAuth belum dikonfigurasi. Isi GOOGLE_CLIENT_ID dan GOOGLE_CLIENT_SECRET.'});
  next();
}
app.get('/api/status', async (_req,res) => {
  const db=await readStore();
  res.json({ok:true,oauthConfigured:Boolean(oauth),aiConfigured:Boolean(process.env.OPENAI_API_KEY),channels:db.channels.length});
});
app.get('/auth/google', requireConfigured, (req,res) => {
  const state=crypto.randomBytes(24).toString('hex');
  req.session.oauthState=state;
  res.redirect(oauth.generateAuthUrl({access_type:'offline',prompt:'consent',include_granted_scopes:true,scope:SCOPES,state}));
});
app.get('/auth/google/callback', requireConfigured, async (req,res) => {
  try {
    if (!req.query.code || req.query.state !== req.session.oauthState) return res.status(400).send('OAuth state tidak valid.');
    delete req.session.oauthState;
    const {tokens}=await oauth.getToken(String(req.query.code));
    oauth.setCredentials(tokens);
    const yt=google.youtube({version:'v3',auth:oauth});
    const result=await yt.channels.list({part:['snippet','statistics'],mine:true});
    const channel=result.data.items?.[0];
    if (!channel) return res.status(404).send('Akun Google ini tidak memiliki channel YouTube yang dapat diakses.');
    const db=await readStore();
    const id=channel.id;
    const existing=db.channels.find(c=>c.id===id);
    const record={id,title:channel.snippet?.title || 'YouTube channel',
      thumbnail:channel.snippet?.thumbnails?.default?.url || '',
      subscribers:channel.statistics?.subscriberCount || '0',
      connectedAt:new Date().toISOString(),tokens};
    if(existing) Object.assign(existing,record); else db.channels.push(record);
    await writeStore(db);
    res.redirect('/?connected=1');
  } catch(e) { console.error('OAuth callback:',e.message); res.status(500).send('Gagal menghubungkan channel. Periksa konfigurasi OAuth dan log server.'); }
});
app.get('/api/channels', async (_req,res)=>{
  const db=await readStore();
  res.json(db.channels.map(({tokens,...safe})=>safe));
});
app.delete('/api/channels/:id', async (req,res)=>{
  const db=await readStore(); db.channels=db.channels.filter(c=>c.id!==req.params.id);
  await writeStore(db); res.json({ok:true});
});
app.get('/api/channels/:id/videos', async (req,res)=>{
  const db=await readStore(); const channel=db.channels.find(c=>c.id===req.params.id);
  if(!channel) return res.status(404).json({error:'Channel tidak ditemukan.'});
  try {
    const auth=new google.auth.OAuth2(process.env.GOOGLE_CLIENT_ID,process.env.GOOGLE_CLIENT_SECRET);
    auth.setCredentials(channel.tokens);
    auth.on('tokens',async updated=>{
      const latest=await readStore(); const item=latest.channels.find(c=>c.id===channel.id);
      if(item){item.tokens={...item.tokens,...updated}; await writeStore(latest);}
    });
    const yt=google.youtube({version:'v3',auth});
    const ch=await yt.channels.list({part:['contentDetails'],id:[channel.id]});
    const uploads=ch.data.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;
    if(!uploads) return res.json({items:[]});
    const list=await yt.playlistItems.list({part:['snippet','contentDetails'],playlistId:uploads,maxResults:20});
    res.json({items:(list.data.items||[]).map(v=>({id:v.contentDetails?.videoId,title:v.snippet?.title,publishedAt:v.snippet?.publishedAt,thumbnail:v.snippet?.thumbnails?.medium?.url}))});
  } catch(e) { console.error('YouTube API:',e.message); res.status(502).json({error:'Gagal mengambil video. Token mungkin kedaluwarsa atau izin API belum aktif.'}); }
});
app.get('/api/drafts', async (_req,res)=>{const db=await readStore();res.json(db.drafts);});
app.post('/api/drafts', async (req,res)=>{
  const {channelId,title,description='',status='draft'}=req.body||{};
  if(!channelId || !title?.trim()) return res.status(400).json({error:'channelId dan title wajib diisi.'});
  if(!['draft','pending_review'].includes(status)) return res.status(400).json({error:'Status awal tidak valid.'});
  const db=await readStore();
  if(!db.channels.some(c=>c.id===channelId)) return res.status(404).json({error:'Channel tidak ditemukan.'});
  const draft={id:crypto.randomUUID(),channelId,title:title.trim(),description:String(description),status,createdAt:new Date().toISOString()};
  db.drafts.unshift(draft); await writeStore(db); res.status(201).json(draft);
});
app.post('/api/ai/ideas', async (req,res)=>{
  if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:'OPENAI_API_KEY belum diatur.'});
  const {topic,audience='penonton umum',count=5}=req.body||{};
  if(!topic?.trim()) return res.status(400).json({error:'Topik wajib diisi.'});
  try {
    const ai=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const response=await ai.chat.completions.create({model:process.env.OPENAI_MODEL||'gpt-4o-mini',
      messages:[{role:'system',content:'Anda adalah strategist YouTube. Hasilkan ide yang orisinal, spesifik, dan tidak menjanjikan hasil pasti. Balas JSON array berisi objek title, hook, angle.'},
      {role:'user',content:`Buat ${Math.min(Math.max(Number(count)||5,1),10)} ide video tentang ${topic} untuk ${audience}.`}],
      response_format:{type:'json_object'}});
    const raw=response.choices[0]?.message?.content||'{}';
    res.json(JSON.parse(raw));
  } catch(e){console.error('AI:',e.message);res.status(502).json({error:'AI gagal membuat ide. Periksa model dan saldo/kuota provider.'});}
});
app.use((err,_req,res,_next)=>{console.error(err);res.status(500).json({error:'Terjadi kesalahan server.'});});
app.listen(PORT,'0.0.0.0',()=>console.log(`Channel Empire Studio running on port ${PORT}`));
