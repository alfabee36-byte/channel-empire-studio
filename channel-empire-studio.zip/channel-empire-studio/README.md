# Channel Empire Studio

Mobile-friendly starter for managing multiple YouTube channels from one dashboard. Designed to be easy to run in GitHub Codespaces from an Android browser.

## Current capabilities
- Connect a YouTube channel with Google OAuth (read-only scope).
- Keep multiple connected channels in one workspace.
- View each channel's recent uploads.
- Save content ideas as local drafts.
- Optional AI idea generation using OpenAI.
- Responsive dashboard for mobile screens.

## Important scope and safety
This starter is **not** a full clone of the uploaded project. It is a clean, smaller foundation to expand. It does not upload, schedule, delete, or publish videos. YouTube authorization is read-only. Drafts are local and require human review. Do not add broad YouTube scopes unless the related feature and approval workflow are implemented and tested.

## Run in GitHub Codespaces
1. Create a new GitHub repository and upload this project, or upload the ZIP contents to an existing repository.
2. Open the repository in Codespaces.
3. In the terminal run:
   ```bash
   npm install
   cp .env.example .env
   ```
4. Configure Google OAuth:
   - Open Google Cloud Console and create/select a project.
   - Enable **YouTube Data API v3**.
   - Configure OAuth consent screen and add your Google account as a test user if the app is in testing.
   - Create OAuth Client ID with application type **Web application**.
   - Add the Codespaces forwarded public URL plus `/auth/google/callback` to Authorized redirect URIs.
   - Set `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REDIRECT_URI`, `APP_URL`, and a strong `SESSION_SECRET` in `.env`.
5. Optional: set `OPENAI_API_KEY` to enable AI ideas.
6. Start:
   ```bash
   npm start
   ```
7. Open port 3000 in the Codespaces Ports tab. Use the public forwarded URL as `APP_URL`.

## Android workflow
Use Chrome on Android to open the forwarded Codespaces port. The dashboard is responsive. Keep the Codespace running while using the app. For a stable public deployment, configure HTTPS, persistent storage, a secure session store, and a proper database before production.

## Data and security
- `data/store.json` contains channel tokens and is intentionally gitignored.
- Never commit `.env`, `data/`, OAuth client secrets, refresh tokens, or API keys.
- The included Express memory session store is for development only. Replace it with a durable session store before deployment.
- Add authentication/authorization before exposing the dashboard publicly.
- Back up encrypted token data securely.
- Rotate any credential that is accidentally committed.

## Roadmap
1. SQLite/PostgreSQL database and per-user accounts.
2. Channel analytics and comment moderation.
3. Script, SEO metadata, thumbnail and Shorts workflows.
4. Content calendar and reminders.
5. Upload and scheduling with explicit per-video approval, quota handling, and audit logs.
6. CI tests, deployment, and monitoring.

## API
- `GET /api/status`
- `GET /api/channels`
- `GET /api/channels/:id/videos`
- `DELETE /api/channels/:id`
- `GET /api/drafts`
- `POST /api/drafts`
- `POST /api/ai/ideas`
- `GET /auth/google`
